import { Component } from '@angular/core';

@Component({
  selector: 'app-user-registratio',
  templateUrl: './user-registratio.component.html',
  styleUrl: './user-registratio.component.css'
})
export class UserRegistratioComponent {

}
