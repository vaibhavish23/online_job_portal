export class Admin {
    adminId: number |string|null|undefined
    adminName: string;
    emailId: string | null | undefined
    password: string | null | undefined
    registrationDate: Date
}
