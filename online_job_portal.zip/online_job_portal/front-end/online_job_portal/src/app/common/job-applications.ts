import { Employee } from "./employee"
import { Job } from "./job"

export class JobApplications {
    applicationId: number
    employee:Employee
    job:Job
}
